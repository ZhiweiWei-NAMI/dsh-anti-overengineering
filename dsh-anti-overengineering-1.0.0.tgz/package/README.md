# DeepSeek Harness 反过度工程化预设

版本：1.0.0。目标运行时：官方 `deepseek-ai/deepseek-harness` 的 **0.2.1-rc.2**，固定提交 `687f282e8625c6b8d11ff58211a90524be2e4317`。

这个包提供一个可安装的原生 preset，以及负责 Jev 判规、写前拒绝、提示注入和冷却计数的 Host 插件。选择 `anti-overengineering` 预设后，模型本轮提出文件修改时，插件把本批修改交给 Jev；达到规则阈值且频率允许时，默认阻止本批修改，并把相应的固定修改提示送入下一轮。

## 安装与启用

1. 在 DeepSeek Harness 的插件安装入口选择 `dsh-anti-overengineering-1.0.0.tgz`，或用 CLI 安装：

   ```bash
   dsh plugin --profile web add /absolute/path/dsh-anti-overengineering-1.0.0.tgz
   ```

2. 配置 Jev 凭据。默认引用名为 `JEV_API_KEY`，由 Harness 原生 credentials 服务解析。可在启动进程的环境中设置，也可在 DSH 原生凭据存储中设置该引用。不要把密钥写入本包的 YAML、源码或提示词。

   Linux / macOS 启动示例：

   ```bash
   read -rsp 'Jev API key: ' JEV_API_KEY
   export JEV_API_KEY
   dsh web
   ```

   Windows PowerShell 启动示例：

   ```powershell
   $jevSecret = Read-Host 'Jev API key' -AsSecureString
   $env:JEV_API_KEY = [System.Net.NetworkCredential]::new('', $jevSecret).Password
   dsh web
   ```

   桌面程序从图标启动时，不会继承另一个终端中新设置的环境变量。可在原生 DSH 凭据存储中设置 `JEV_API_KEY` 引用，或从已配置环境的进程启动；包内 `03-native-preset-and-workflow.zh.md` 给出存储文件格式。

3. 重启 Harness，创建新会话，在预设选择器中选择 **`anti-overengineering`**。安装后仍可使用原有 standard；本包没有改变全局默认预设。

4. 使用原生 `write` / `edit` 完成文件修改。命中时工具结果会说明本批尚未执行，随后出现“反过度工程化”修改提示，模型在下一轮重提补丁。没有命中时继续原生执行流程。

已有的权限拒绝与审批流程继续生效。Jev 只能使某次写入被拒绝，不会将原生 `ask` 转成 `allow`。

## Jev 服务配置

默认使用官方 TypeSafe：

```yaml
judge:
  endpoint: https://api.typesafe.ai/v1/systemone
  model: jev-latest
  apiKeyEnv: JEV_API_KEY
  timeoutMs: 15000
  onError: allow
  contextChars: 24000
```

`endpoint`、`model` 和凭据必须来自同一服务。`jev-latest` 是官方示例中的模型名称，不是固定权重版本。若使用你现有的 OpenCode Jev 线路，可将三项分别配置为该线路的地址、模型名与对应凭据引用；不要只改地址。

一次请求共享一份 state，10 条规则分别是 `noul` 问题。读取结果为 `answers.AE01.noul` 等；这个类型没有独立的 `confidence` 字段。提示词由本地规则库按 ID 选择，Jev 不生成修正段落或文件行号证据。

`onError: allow` 表示超时、缺凭据、HTTP 错误或无效答案时保留原生执行决策，并记录判规失败；这不代表规则通过。可改为 `deny`，要求判规成功后再写入。没有自动重试或替代模型。

## 默认触发配置

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `threshold` | 0.85 | 规则 Noul 达到此值才算命中 |
| `cadence.checkEveryWriteRounds` | 1 | 每个含受监控写操作的模型轮检查一次 |
| `cadence.globalCooldownRounds` | 2 | 一次干预后，随后两个模型轮不再干预 |
| `cadence.sameRuleCooldownRounds` | 6 | 同规则干预后，随后六个模型轮不再重复提示该规则 |
| `cadence.windowRounds` | 20 | 频率窗口宽度，以模型轮计 |
| `cadence.maxInterventionsPerWindow` | 4 | 任意连续 20 个模型轮最多干预 4 次 |
| `cadence.maxInterventionsPerSession` | 12 | 每个原生 Session 最多干预 12 次；达到后停止本插件判规 |
| `cadence.maxJevCallsPerSession` | 0 | 0 为不设调用次数上限；失败尝试也占一次 |
| `cadence.maxRulesPerIntervention` | 3 | 一条提示最多包含 3 条修改要求 |

这些数值是本交付的初始配置，不是论文结论、官方推荐阈值或已经校准的概率。

**一轮 = 一次模型 step，包含该次模型回复及其工具批次。** 使用原生 `sessionStats.steps + 1` 计数；只读轮也推进冷却。若第 10 轮触发，全局冷却 2 会抑制第 11、12 轮，第 13 轮可再次干预；同规则冷却 6 会抑制第 11–16 轮，第 17 轮可再次干预。

检查采样与提示冷却独立：默认冷却期间仍检查写批次并记录分数，但不重复干预。同一批多次写入先复用该批判断，全部得到一致的拒绝结果，仅注入一次提示。下一轮处于冷却时会按原生权限继续，这是一项可调的纠偏频率策略，不是每次命中都强制禁止写入。

计数使用原生 `storageDomain`，以 Session ID 为键保存，正常进程重启后延续。不同会话、不同子会话分别计数；不是全进程共享预算。会话被导出到另一份 DSH 数据目录时，旁表不会自动跟随会话日志一起导出。

## 配置单条规则

本包的 `cordis.patch.yml` 已写全默认配置。可以在 Harness 插件配置中修改 `anti-overengineering-runtime`，也可以在自己的 profile patch 中按同名 ID 覆盖。例如：

```yaml
- id: anti-overengineering-runtime
  config:
    enabled: true
    presetIds: [anti-overengineering]
    mode: revise
    threshold: 0.85
    rules:
      AE03:
        threshold: 0.90
        cooldownRounds: 10
      AE08:
        enabled: true
        correction: "只验证本次改动的可观察行为，删除实现镜像测试和重复覆盖；通过必要检查后继续交付。"
```

原生 patch 的 `config` 是整项替换，不是深合并。这个例子中未写出的配置恢复插件默认值；若你已经改过 Jev 地址、频率等字段，请把要保留的配置一并带上。未知规则 ID 会在加载时报告错误，避免拼错后误以为生效。

`mode: revise` 为默认，写前拒绝后要求重提；`mode: remind` 只追加提示，本插件不额外拦截写入，仍以原生审批和实际工具结果为准。

## 规则库

| 规则 | 内容 |
|---|---|
| AE01 | 任务范围扩张 |
| AE02 | 假想未来需求与配置膨胀 |
| AE03 | 一次性抽象与多层包装 |
| AE04 | 假设性防御与重复校验 |
| AE05 | 无依据兼容层与双路径 |
| AE06 | 无依据的性能机制 |
| AE07 | 无关重构、格式与说明扩散 |
| AE08 | 低价值测试与验证扩张 |
| AE09 | 多余脚手架、产物与依赖 |
| AE10 | 精简损伤行为或可读性 |

`rules.json` 是实际执行规则库，包含 Jev 判定问题、中文触发条件、豁免、中英修改提示和来源。它保留用户要求、真实外部输入校验、必要测试、已知消费者、已有部署约束和功能完整性。

## 检查覆盖范围

官方 standard 预设当前的原生文件修改工具为 `write` 和 `edit`。配置还列出 `apply_patch`、`multi_edit`，供实际安装了这些工具的环境使用；本包不会创建这些工具。`str_replace_editor` 只在 `create` / `str_replace` / `insert` 时检查，`view` 不检查。

本包按工具名与动作识别，不解析任意 Bash、PowerShell、Python 或第三方工具中的文件副作用。因此默认不拦纯 shell 写文件，也不拦纯 shell 反复运行测试。AE08 检查的是准备新增或修改的测试代码。需要纳入其他明确的文件修改工具时，将其真实名称加入 `writeTools`；不要据此声称覆盖了所有 shell 副作用。

Jev 的输入是当前可见用户要求、最近的公开文本证据及完整待写入参数。历史证据按 `contextChars` 限制并标记遗漏，待写入参数不截断；不发送 reasoning 块或系统提示。上下文不足时规则明确要求避免肯定误报。非常大的写入可能被 Jev 服务拒绝，此时按 `onError` 处理。

## 源码与验证

运行码在 `index.js` 与 `policy.js`，无需安装时构建或新增聊天模型 provider；依赖已有 Harness 服务和随宿主提供的库。原生 standard 的完整插件列表保留在 `cordis.patch.yml`，没有使用不存在的 `extends: standard`。

最终包的验证记录见外层 `04-validation.zh.md`。验证使用固定官方运行时与模拟 Jev 返回；未调用用户的付费 Jev 接口，不据此声明真实判规准确率或性能收益。当前标准 Web/Desktop 组合提供所需服务；这份 preset 不宣称是裸 headless profile 的完整引导配置。

原生配置依据：[Agent preset registry](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/preset/agent-preset-registry/README.md)、[Tool pipeline](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/docs/tool-execution-pipeline.md)、[Storage domain](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/storage/storage-domain/README.md)。原文副本、许可证和固定版本来源清单包含在外层资料包内。
